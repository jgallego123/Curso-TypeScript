interface Auto{
    marca:String,
    estado:String
}
function getEstado(auto:Auto){
    console.log('El estado del auto es: ' + auto.estado);
}
function getMarca(auto:Auto){
    console.log('La marca del auto es: '+ auto.marca)
}
let newAuto:Auto={
    marca:'Mazda',
    estado:'Deteriorado'
}
console.log(newAuto)
getEstado(newAuto)
getMarca(newAuto)