function getEstado(auto) {
    console.log('El estado del auto es: ' + auto.estado);
}

function getMarca(auto) {
    console.log('La marca del auto es: ' + auto.marca);
}
var newAuto = {
    marca: 'Mazda',
    estado: 'Deteriorado'
};
console.log(newAuto);
getEstado(newAuto);
getMarca(newAuto);