var Jugador = /** @class */ (function() {
    function Jugador(nombre, equipo, esSeleccion, edad) {
        this.nombre = nombre,
            this.equipo = equipo,
            this.esSeleccion = esSeleccion,
            this.edad = edad;
    }
    return Jugador;
}());
var Messi = new Jugador('Lionel', 'Barcelona', true, 35);
console.log(Messi);