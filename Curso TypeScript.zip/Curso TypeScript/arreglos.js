var arreglo = [1, 2, 3, 4, 5, 6];
var arregloAuto = ["Jaguar", "Bentley", "Chrysler"];
arregloAuto.push("Audi");
console.log(arregloAuto);
console.log(arregloAuto[3]);
