let automovil:any;
//Variable String
automovil="Mercedes Benz";
console.log(automovil.charAt(0));
//Variable numerica
automovil=150.555;
console.log(automovil.toFixed(2));
//Variable booleana
automovil=true;
console.log(automovil);

