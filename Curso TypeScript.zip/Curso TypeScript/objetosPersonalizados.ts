//Creando tipo de dato: equipo
type Equipo={
    nombre:String,
    edad:Number,
    titulos:Number,
    ligas:String[],
    getDatos:()=>String
};

let manchesterUnited:Equipo={
    nombre:'Manchester United',
    edad: 112,
    titulos: 52,
    ligas:['liga inglesa','champions league','copa inglesa'],
    getDatos(){
        return this.nombre;
    }
}
console.log(manchesterUnited);