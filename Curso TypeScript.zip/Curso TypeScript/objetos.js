var equipo;
equipo = {
    nombre: 'Atletico Nacional',
    titulos: 26,
    competencias: ['Liga aguila, Copa Colombia, Copa libertadores']
};
console.log(equipo);
