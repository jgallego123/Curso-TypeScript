let arreglo:number[]=[1,2,3,4,5,6];

let arregloAuto:string[]=["Jaguar","Bentley","Chrysler"];

arregloAuto.push("Audi");

console.log(arregloAuto);

console.log(arregloAuto[3]);