let ganador:boolean=true;

if(ganador){
    console.log("Ganador");
}else{
    console.log("Perdedor");
}

ganador=perdedor();

function perdedor(){
    return false;
}
console.log(ganador);
