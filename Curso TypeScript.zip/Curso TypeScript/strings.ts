let brandt:string="Julian Brandt";
let hazard:string='Eden Hazard';
let kane:string=`Harry Kane`;

console.log(brandt);
console.log(hazard);
console.log(kane);

let concatenar:string="El jugador elegido es: "+brandt;

let concat:string=`Los jugadores son: ${brandt}, ${hazard}, ${kane}`;
console.log(concatenar);
console.log(concat);