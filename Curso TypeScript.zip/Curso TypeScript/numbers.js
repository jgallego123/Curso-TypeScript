var puntos1 = 10;
var puntos2;
var puntos3 = 6;
puntos2 = 7;
if (puntos1 > puntos3) {
    console.log('El mayor es puntos 1');
}
else {
    console.log('El mayor es puntos3');
}
