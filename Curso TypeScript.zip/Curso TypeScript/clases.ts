class Jugador{
    nombre:String;
    equipo:String;
    esSeleccion:boolean;
    edad:number;

    constructor(nombre: String, equipo:String,esSeleccion:boolean, edad:number){
        this.nombre=nombre,
        this.equipo=equipo,
        this.esSeleccion=esSeleccion,
        this.edad=edad
    }
}

let Messi:Jugador = new Jugador('Lionel','Barcelona',true,35);
console.log(Messi);