var manchesterUnited = {
    nombre: 'Manchester United',
    edad: 112,
    titulos: 52,
    ligas: ['liga inglesa', 'champions league', 'copa inglesa'],
    getDatos: function() {
        return this.nombre;
    }
};
console.log(manchesterUnited);